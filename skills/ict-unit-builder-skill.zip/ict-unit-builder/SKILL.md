---
name: ict-unit-builder
description: "Builds a complete BGA-format ICT/Computing unit from a topic and grade level — unit overview with department-structured objectives, a running unit scenario, per-lesson plans in BGA's five-phase lesson layout, level-linked success criteria, slide-deck outlines, printable worksheets, and a summative task with rubric. Use this whenever the user wants to plan, build, draft, scaffold, or outline a new unit, topic, scheme of work, or sequence of ICT/Computing/CS lessons — including requests like 'plan a unit on X', 'I need lessons for Grade 6 on Y', 'build me a scheme of work', 'draft a new topic for 7 RED', or when they need a lesson plan, worksheet, success criteria, or summative task for an ICT topic. Also use when adapting or rebuilding an existing unit for a different grade or section."
---

# BGA ICT Unit Builder

Turn a topic and a grade level into a complete, teachable unit in British-Georgian Academy house format.

This skill produces the planning scaffold — objectives, lesson-by-lesson plans, deck outlines, worksheets, and assessment. It does not replace subject expertise; it removes the blank page and enforces the department's format so every unit comes out consistent.

**Companion skill:** if `ict-curriculum-master-teacher` is available, use it for pedagogical depth on Grades 3–7 topics (unplugged approaches, Scratch block notation, Python scaffolding for beginners). This skill governs *structure and format*; that one governs *subject pedagogy*. Use both together.

---

## Step 1 — Establish the brief

Confirm these before building. Ask only for what's genuinely missing; infer the rest and state what you inferred.

| Input | Notes |
|---|---|
| **Topic** | The unit subject, e.g. "Python turtle graphics", "3D modelling in Tinkercad" |
| **Grade** | 3–7 for primary/middle; 8, IGCSE (9–10) and DP (11–12) objectives also exist |
| **Number of lessons** | Default to 5–6 if unstated. Ask if the unit looks larger. |
| **Sections** | Which classes it runs in (e.g. 6 BLUE, 6 RED). Affects differentiation only. |
| **Summative?** | Whether this unit ends in an assessed task. Default yes. |

If the topic matches a unit already in the department curriculum, say so and use the official objectives rather than writing new ones. Read `references/curriculum-map.md` to check.

---

## Step 2 — Set the objectives

Read `references/curriculum-map.md` for the department's objective structure and the existing unit list by grade.

Objectives follow a fixed three-part shape:

```
**Main Goal:** <one sentence — what students can do by the end of the unit>

- Knowledge & Understanding:
  1. <conceptual objective>
  2. <conceptual objective>

- Practical Skills:
  1. <hands-on, tool-specific objective>
  2. <hands-on, tool-specific objective>

- <Third domain>:
  <objective(s)>
```

The third domain is chosen to fit the unit, matching how the department already varies it: *Algorithmic Thinking*, *Design & Innovation*, *System Analysis*, *Data Visualization*, *Data Presentation*, *Data Types*, *Design & User Experience (UX)*.

Write objectives as things a student **does**, using observable verbs (identify, explain, construct, convert, trace, evaluate, design). Avoid "understand about" and "learn how to".

---

## Step 3 — Choose a unit scenario

BGA ICT units run on a single narrative frame that threads every lesson together. The Grade 7 cybersecurity unit, for example, casts students as security experts hired by the "International Space Organisation", with each lesson a new task defending the organisation.

Invent one scenario for the unit and carry it through every lesson. It should:

- give students a **role** ("You have been hired as…")
- supply a **client or organisation** with a believable need
- generate a **task per lesson** that fits the lesson's objective naturally
- resolve in the summative task

A weak scenario is decoration. A strong one makes the summative feel like the job you were hired to do. Do not force one onto a unit where it genuinely doesn't fit (some skills-drill units are better plain) — but try first.

---

## Step 4 — Sequence the lessons

Lay out the unit as a table before writing any individual plan:

| # | Lesson title | Objective focus | Scenario task | Key activity | Check |
|---|---|---|---|---|---|

Sequencing rules:

- **Concept before tool.** One lesson establishing the idea before the software appears.
- **Unplugged first for Grades 3–5.** Paper, movement, or discussion before screens.
- **Build toward the summative.** Every lesson should produce something the summative reuses.
- **Penultimate lesson is prep.** Reserve the second-to-last lesson for summative preparation — the department's existing units do this ("Lesson 8 Summative Prep").

Show the user this table and get agreement before expanding into full lesson plans. It is much cheaper to fix the sequence here.

---

## Step 5 — Write each lesson plan

Read `references/bga-lesson-format.md` for the full five-phase layout, the three-level learning objective pattern, and how success criteria are written.

Every lesson plan must contain all five phases: **Before the Lesson**, **Entry and Do Now** (10 min max), **Roadmap / LO and outcomes** (5 min max), **Main Activities**, **Plenary and Exit**.

Two things are non-negotiable in BGA format and are the most common omissions:

1. **The LO is written at three levels** — Introduction / Development / Depth — a genuine progression from identifying to explaining to evaluating.
2. **Success criteria accompany every significant task**, written in student-friendly language and linked to levels (Level 4 / Level 5 / Levels 6-7). Never generic grade descriptors.

Use `assets/lesson-plan-template.md` as the output shape.

---

## Step 6 — Outline the slide deck

Read `references/deck-conventions.md` for the observed slide sequence and activity-numbering scheme.

Produce a slide-by-slide outline per lesson — headline plus the content that goes on each slide. Activities are numbered `Activity <lesson>.<n>` (Activity 3.1, 3.2 …). Include the Do Now, the discussion prompts, and the closing quiz slide.

Offer to build the actual `.pptx` (use the `pptx` skill) or to create it as a Google Slides deck in the unit's Drive folder — but only after the outline is approved.

---

## Step 7 — Build the worksheet and summative

**Worksheet** — one printable per lesson that needs one. Give it a title, the student-friendly success criteria at the top, and tasks that escalate through the three LO levels so support and extension are built in rather than bolted on.

**Summative task** — a single task that requires the whole unit, framed as the scenario's resolution. Pair it with a rubric using the same Level 4 / 5 / 6-7 bands as the success criteria, so students have seen the standard all unit.

Remind the user to book the summative date on the shared **Assessment Calendar** (`შემაჯამებელი დავალების განრიგი_Assessment Calendar_2026_2027`), which is organised by class and date — the unit isn't finished until the date is booked.

---

## Step 8 — Deliver

Default output is a single markdown unit pack the user can review in one pass. Then offer, in one line:

- **Word document** — use the `docx` skill (matches the department's `.docx` planning files)
- **Slide decks** — use the `pptx` skill, or create Google Slides directly
- **Save to Drive** — into `5. ICT Curriculum & Planning` or the relevant `ICT (combined)` grade/unit folder, following the existing `Grade N / Unit N - Title / Lesson N` structure

Do not build every format speculatively. Produce the plan, then let the user pick.

---

## Quality bar

Before handing over, check:

- [ ] Every lesson has all five phases, none collapsed or skipped
- [ ] Every LO is written at three levels with a real cognitive progression
- [ ] Success criteria are student-facing and level-linked, not teacher jargon
- [ ] The scenario appears in every lesson, not just lesson 1
- [ ] Each lesson produces something the summative uses
- [ ] Tool-specific instructions are correct and version-appropriate (Scratch block notation, Python syntax, MakeCode, Tinkercad)
- [ ] Digital citizenship or ethics is embedded wherever the topic touches it
- [ ] Nothing is padded — a five-lesson unit with four lessons of content should be four lessons

State honestly where the plan is thin or where a topic needs resources the school may not have (hardware, licences, lab time). A plan that quietly assumes 25 micro:bits is worse than one that flags the dependency.
