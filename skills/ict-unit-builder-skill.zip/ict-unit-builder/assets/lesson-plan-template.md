# Lesson <N>: <Title>

**Unit:** <Unit Title>  ·  **Grade:** <N>  ·  **Duration:** <45 min>

**Key Question:** <the KQ, or omit if using an LO>

**Learning Objective — three levels:**
- **Introduction:** <identify / recall / use — reachable by every student>
- **Development:** <explain / apply / choose>
- **Depth:** <evaluate / connect / design — not just more of the above>

---

## Before the Lesson

- Upload to Google Classroom / ManageBac: <files>
- Prepare: <equipment, logins, printed sheets>
- Check: <anything that has failed before — logins, software versions, network access>

## Entry and Do Now — 10 min max

**Do Now:** <the task, written as students will see it>

<Reviews prior learning from lesson N-1 / primes the new concept. If the previous lesson was assessed, use the Do Now for silent review of feedback.>

## Roadmap, LO and Outcomes — 5 min max

Write the LO on the board and leave it up for the lesson.

**Say:** <how this lesson connects backwards to what students already did and forwards to where the unit is going — one or two sentences>

**Scenario:** <this lesson's task within the unit narrative>

## Main Activities

### Activity <N>.1 — <title> · <minutes>

<What students do, written concretely.>

**Success criteria:**
- **Level 4:** <student-friendly, countable, concrete>
- **Level 5:** <escalates>
- **Levels 6/7:** <escalates — reasoning, connection, evaluation>

### Activity <N>.2 — <title> · <minutes>

<Task.>

**Success criteria:**
- **Level 4:** <…>
- **Level 5:** <…>
- **Levels 6/7:** <…>

### Activity <N>.3 — <title> · <minutes>

<Task. Often the applied or extension activity.>

**Support:** <scaffold for students working at Introduction level>
**Extension:** <for students who reach Depth early>

## Plenary and Exit

**Assessment for Learning:** <how you check the LO was met — cold call, exit ticket, Kahoot, thumbs, mini-whiteboards>

**Quiz / check:** <Kahoot link or exit question>

**Exit routine:** Students pack away and wait silently behind desks, then leave quickly and quietly.

---

## Deck outline

| Slide | Content |
|---|---|
| 1 | **<Unit Title>** — Lesson <N>: <title> |
| 2 | **Objectives** — "In this lesson, you will learn:" <bullets> |
| 3 | **<Scenario slide>** — <text> |
| 4 | **Activity <N>.1 / DO NOW** — <text> |
| … | |
| last | **Quiz** — <Kahoot link> |

## Notes

- **Misconceptions to watch for:** <the specific wrong idea students form here>
- **Assets to source:** <anything the teacher must find or make>
