# Unit Plan — <Unit Title>

**Grade:** <N>  ·  **Sections:** <e.g. 6 BLUE, 6 RED>  ·  **Lessons:** <N>  ·  **Summative:** <Yes / No>

---

## Objectives

**Main Goal:** <one sentence — what students can do by the end of the unit>

- **Knowledge & Understanding:**
  1. <objective>
  2. <objective>

- **Practical Skills:**
  1. <objective>
  2. <objective>

- **<Third domain>:**
  <objective>

---

## Unit scenario

<The running narrative. Student's role, the organisation, the overall brief. 2–4 sentences, written in second person as it will appear on the deck.>

**Lesson tasks within the scenario:**

| Lesson | Scenario task |
|---|---|
| 1 | <task> |
| 2 | <task> |

---

## Lesson sequence

| # | Lesson title | Objective focus | Scenario task | Key activity | Check |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| … | | | | | |
| n-1 | Summative Prep | | | | |
| n | | | | | |

---

## Summative task

**Task:** <what students produce — the resolution of the scenario>

**Format:** <document / program / model / presentation>  ·  **Time:** <lessons or minutes>

**Rubric**

| Level | Criteria |
|---|---|
| **Level 4** | <student-friendly, countable, concrete> |
| **Level 5** | <escalates on the same axes> |
| **Levels 6/7** | <escalates again — reasoning and evaluation> |

**Assessment Calendar:** book the date for each section on `შემაჯამებელი დავალების განრიგი_Assessment Calendar_2026_2027`.

---

## Resources and dependencies

- **Software / accounts:** <e.g. MakeCode, Tinkercad, Python IDE>
- **Hardware:** <e.g. 15 micro:bits — flag if uncertain the school has these>
- **Prepared assets needed:** <screenshots, printables, sample files the teacher must source>
- **Existing BGA resources to reuse:** <Kahoots, decks, Twinkl packs already in Drive>

---

## Prior learning and next steps

**Builds on:** <earlier unit(s)>
**Leads to:** <later unit(s)>
