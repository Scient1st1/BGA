# BGA Lesson Format

The house lesson structure, taken from BGA's `BGA lesson layout .docx`. Every lesson plan this skill produces must follow it.

## The five phases

| Phase | Purpose | Teacher actions |
|---|---|---|
| **Before the Lesson** | Ensure all resources are accessible | Upload work to Google Classroom / ManageBac. Ensure resources are available for student review. |
| **Entry and Do Now** (10 min max) | Review prior learning, or get students thinking about the next learning | Greet students, check behaviour and seating. Students complete the Do Now task independently. |
| **Roadmap, LO and outcomes** (5 min max) | Focus students on the lesson's content and how it fits a wider sequence of learning, both forwards and backwards | Introduce the Key Question (KQ) or Learning Objective (LO) and share lesson outcomes. Write it on the board so it stays up until the end of the lesson. |
| **Main Activities** | Introduce new knowledge or skills. **Success criteria are provided for every significant task.** | Well-sequenced, student-centred learning: collaboration, group/pair/class discussion, structured group work, student voice influencing lesson planning, student reflection, inquiry-based learning, activities fostering imagination and creativity. |
| **Plenary and Exit** | Review learning, identify misconceptions, ensure calm and orderly dismissal | Use Assessment for Learning to check whether students met the KQ/LO. Students pack away and wait silently behind desks, then leave quickly and quietly. |

Time boxes on Do Now and Roadmap are maximums, not targets. The bulk of the lesson is Main Activities.

## The three-level learning objective

The LO is not one line. It is written as a progression across three levels, so students can see where they are and what "further" looks like.

The department's worked example (from History):

- **Introduction:** Identify different causes of World War I
- **Development:** Explain how each cause led to the outbreak of war
- **Depth:** Evaluate which event increased tensions most significantly and link events together

The pattern is **identify → explain → evaluate/connect**. Applied to ICT:

| Unit | Introduction | Development | Depth |
|---|---|---|---|
| Binary & logic | Convert denary numbers to 8-bit binary | Explain why computers use binary rather than denary | Trace a multi-gate logic circuit and predict its output for any input |
| Python sequence | Use `print()` and create a variable | Explain what each line of a program does and fix a syntax error | Restructure a program so it takes user input and adapts its output |
| Spreadsheets | Enter and format data, and use `=SUM` | Choose the right function for a given question about the data | Design a spreadsheet that answers a question nobody has asked yet |

Write all three levels every time. The Introduction level must be genuinely reachable by the weakest student in the room, and the Depth level must not be reachable by simply doing more of the Development level.

## Success criteria

Success criteria are required for **every significant task**. The department's rules:

- Written in **student-friendly language**
- **Specific** criteria students can self-assess against
- **Grade-linked** — tied to levels
- **Avoid generic or vague grade descriptors**

They use banded levels. The department's worked example, again from History, for the task *"Write an essay: Did one bullet lead to 20 million deaths in World War I?"*:

- **Level 4:** States three events that may have contributed to the outbreak of war. Provides at least one fact, date or additional piece of information to help explain why it led to war.
- **Level 5:** Shows clear knowledge of three events that led to the outbreak of World War I. Outlines a connection between these events and the outbreak of war. Gives suggestions as to which cause made war most likely.
- **Levels 6/7:** Shows detailed knowledge of 3 key events that led to the outbreak of war. Shows developed links between these events. Shows supported reasoning why one event made war more likely.

Note what makes these work, and copy it: each band names a **countable quantity** (three events), a **quality of connection** (outlines → developed links), and a **level of reasoning** (suggestions → supported reasoning). Bands escalate on those same axes rather than swapping in new vocabulary.

An ICT equivalent, for a task building a micro:bit step counter:

- **Level 4:** My program uses the accelerometer to detect movement and shows a number on the LED screen. I tested it at least once.
- **Level 5:** My program counts steps accurately and resets when button A is pressed. I tested it with a set number of steps and fixed at least one bug I found.
- **Levels 6/7:** My program counts steps accurately, resets, and handles an unexpected input without crashing. I can explain why I structured the code the way I did, and I identified a limitation of using the accelerometer for this.

## Teaching strategies referenced by the department

Weave these into Main Activities and Plenary where they fit. From the layout document's strategy table:

**Set clear and achievable targets** — precise, easy to understand, tailored to the individual, realistic given prior attainment, in student-friendly language.

**Make student response / redraft a consistent part of teaching** — return marked work to all students at once; use the next lesson's Do Now for students to review feedback silently; guide students to act on feedback; reinforce with whole-class examples of strengths (WWW — What Went Well) and improvements (EBI — Even Better If); track common errors for future reference.

**Student reflection and redrafts** — students reflect before responding to feedback; after redrafting, they state specifically how they improved, using sentence starters such as *"Today I have improved my work because…"*

**Peer assessment** — student-friendly success criteria, marking in green pen, a checklist for specific elements, scaffolded summary comments; students sign off feedback with name and date for accountability.

**Use of talk in the classroom** — discuss in groups before writing, with clear purpose and time limit; structure discussion with specific questions; encourage full-sentence answers; support with sentence starters and key vocabulary; develop the four strands of oracy (physical, vocabulary, cognitive, social/emotional).

A "Do Now that reviews feedback from the last piece of marked work" is the department's named practice — reach for it in the lesson after any assessed task.

## Related document

`BGA Fully Inclusive classroom .docx` is referenced from the lesson layout for inclusion and differentiation guidance. Consult it when a unit needs significant adaptation.
