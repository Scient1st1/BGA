# BGA ICT Curriculum Map

Existing units by grade, and the department's objective structure. Check here first — if the requested topic is already an official unit, use its objectives rather than writing new ones.

Source: the department's *Objectives by Grade levels* document and the ICT curriculum scope. The live version lives in Drive (`5. ICT Curriculum & Planning`); re-check it if a unit looks out of date.

---

## Objective structure

Every unit in the department document follows this shape:

```
### N. Unit Title
**Main Goal:** <single sentence>

- Knowledge & Understanding:
  1. …
  2. …

- Practical Skills:
  1. …
  2. …

- <Third domain>:
  …
```

The third domain varies by unit and is chosen to fit. Domains already in use across the curriculum:

`Algorithmic Thinking` · `Design & Innovation` · `System Analysis` · `Data Visualization` · `Data Presentation` · `Data Types` · `Design & User Experience (UX)` · `Practical & Analytical Skills` · `Technical Concepts` · `Legal & Professional Awareness`

Match one of these when possible; invent a new one only if none fits.

---

## Grades 3–5 (curriculum scope)

These grades are defined by topic scope rather than the full objective format. When building a unit here, write objectives in the three-part structure above.

**Grade 3**
- Online Searchers and Surfers — internet basics, connections, browsers, search engines, web trust, online safety, copy-pasting images, scavenger hunt project
- Word Processing Skills — typing, text formatting, creating/saving/retrieving documents, image insertion, layout
- Be Internet Awesome — digital literacy, evaluating online content, cyber threats, privacy, responsible sharing
- Data Handling / Branching Databases — collection and organisation, sorting, basic charts, data privacy
- Programming Loops — block-based loops, repetition, basic debugging

**Grade 4**
- Coding with Scratch (Questions & Quizzes) — variables, comparison and arithmetic operators, outcome prediction, naming conventions
- Scratch Games — interface, animations, stories, sequences, loops, conditionals, user input, sound, peer feedback
- Scratch Continued — complex interactive projects, planning before coding, systematic testing and debugging, evaluation
- Online Safety — personal information, password security, suspicious links, cyberbullying response, information reliability, trusted adult protocols
- Word Processing / PowerPoint — slide design, layouts, media formatting, transitions, animations, templates, citation

**Grade 5**
- Humans Think, Computers Obey — software design basics, unplugged computational thinking, flowcharts, Scratch drawing with subroutines
- Smart Circuits and Physical Computing — Tinkercad Circuits (LEDs, switches, buzzers), intro to microcontrollers
- Data Management Systems (Spreadsheets) — Excel navigation, entry and formatting, search/sort, SUM and AVERAGE, real-world scenarios
- Networks and Internet Communication — email practice, account setup, attachments, contacts, safe search
- Canva Presentations — visual design, multimedia formatting, transitions, templates, attribution
- Computing — Past, Present and Future — hardware history, processing growth, tech trends
- Binary, Storage & AI Basics — binary concepts, storage units, intro machine learning

Grades 3–5 lean **unplugged first**: paper-based logic, physical games and discussion before the screen. Block coding before text coding.

---

## Grade 6

1. **Physical Computing with Micro:Bit** — microcontroller vs desktop computer; inputs (sensors, buttons) and outputs (LED screen, pins); MakeCode build/test/debug; accelerometer, light and temperature sensors; buttons A and B as event triggers. *(The department's copy of this entry is truncated mid-sentence and its Algorithmic Thinking objectives are missing — write them fresh and flag it.)*
2. **3D Modelling in Tinkercad** — navigate a 3D workspace on X/Y/Z; decompose real structures into primitives; import, resize, rotate, align, position; Group and Hole tools; independently design a functional prototype (keychain, mug, architectural model)
3. **Computing Components** — input vs output devices; CPU, RAM, Storage (HDD/SSD); trace how data travels input → CPU/RAM → output
4. **Introducing Spreadsheets** — columns, rows, cells, cell references; enter, edit and format data including currency and percentages; arithmetic formulas, `=SUM`, `=AVERAGE`; select data to generate bar and pie charts
5. **Programming in Python — Sequence** — sequential execution; syntax errors; `print()`; variables; `input()`; strings, integers, floats and casting

## Grade 7

1. **Internet Safety, Cybersecurity and Encryption** — phishing, malware (viruses, trojans, ransomware), social engineering, identity theft; encryption and HTTPS; password strength and MFA; red flags in emails, links and URLs; symmetric encryption by hand with simple ciphers (Caesar)
2. **Advanced Spreadsheets** — absolute (`$A$1`) vs relative (`A1`) references; conditional formatting; `=IF`, `=COUNTIF`, multi-variable operations; sort, filter, organise complex datasets; professional charts with correct axis labelling
3. **Binary and Computer Logic** — why binary (transistor on/off states); AND, OR, NOT; denary ↔ 8-bit binary up to 255; truth tables for single and combined gates; standard gate symbols; trace inputs through a simple circuit
4. **Algorithms** — algorithm vs program; decomposition, pattern recognition, abstraction; read, interpret and write algorithms; structured flowcharts with correct symbols (Process, Decision, Input/Output, Start/End); trace tables and dry running
5. **Programming in Python — Sequence** — as Grade 6 unit 5

> **Known discrepancy — resolve with the Head of Department before building.** The department's *Objectives by Grade levels* document lists **Sequence** for Grade 7 unit 5 (identical text to the Grade 6 unit), and places **Selection & Iteration** in Grade 8. The ICT curriculum scope instead has Grade 7 covering **Selection & Iteration**. These cannot both be right. When asked to build a Grade 7 Python unit, surface this and ask which is intended rather than silently choosing.

## Grade 8

1. **Programming in Python — Selection and Iteration** — selection and iteration as constructs; indentation defining code blocks; relational (`==`, `!=`, `<`, `>`, `<=`, `>=`) and logical (`and`, `or`, `not`) operators; `if`/`elif`/`else`; count-controlled `for` loops; condition-controlled `while` loops and avoiding infinite loops
2. **Networking and the Internet** — LAN vs WAN; client-server vs peer-to-peer; routers, switches, hubs, NICs; packet switching and IP routing; wired (Ethernet, fibre) vs wireless (Wi-Fi, Bluetooth) on speed, range, reliability
3. **Ethics of Computing** — rare-material extraction, data-centre energy use, e-waste; the digital divide; copyright, data protection and computer misuse law; AI and automation on jobs and decision-making bias
4. **Physical Computing with Micro:Bit** — as Grade 6 unit 1 *(also truncated in the source document)*
5. **Designing Websites** — HTML structures content, CSS styles it; `<html>`, `<head>`, `<body>`, `<h1>`–`<h6>`, `<p>`, `<ul>`, `<ol>`, `<a>`; inline, internal and external CSS for layout, fonts, background, margins; wireframing for navigation, usability and accessibility
6. **Sound and Video Editing** — digitisation (sample rate, bit depth, frame rate); MP3 vs WAV, MP4 vs MOV, compression; audio cut/splice/layer with fades, noise reduction, normalisation; video timeline arrangement, purposeful transitions, titles, voiceover sync

## Grades 9–10 (IGCSE Computer Science)

Two-year course. Section 1 *Computer Systems*: Data Representation · Data Transmission · Hardware · Software · Automated and Emerging Technologies. Section 2 *Algorithms, Programming and Logic*: Algorithm Design and Problem-Solving · Programming · Logic Gates and Circuits · Data Security and Databases.

Course aims: computational thinking, problem-solving with computers, high-level programming, computer systems, internet communication and risks, awareness of automated and emerging technologies.

## Grades 11–12 (DP Computer Science)

Computer systems, networks, databases, machine learning, computational thinking, programming in Python or Java, OOP, files, SQL, technical documentation, the case study, and the internal assessment computational solution.

IB assessment objectives: **AO1** knowledge and understanding · **AO2** application and use of knowledge · **AO3** construction, synthesis, analysis and evaluation · **AO4** application of computational thinking to real-world problems.

---

## Drive structure

Units live under a consistent hierarchy. Follow it when saving:

```
ICT (combined)  /  Grade N  /  Unit N - Title  /  Lesson N  /  <deck, worksheets, resources>
5. ICT Curriculum & Planning  /  <syllabus, objectives, planning documents>
```

Supporting documents referenced by the department:

- **Syllabus outline** — `2027_2028_ICT/CS_Curriculum_Booklet` (in progress)
- **Objectives by Grade levels** — the source for this map
- **Assessment Calendar** — `შემაჯამებელი დავალების განრიგი_Assessment Calendar_2026_2027`, a class-by-date grid where summative dates are booked
- **Grade books** and the student comment bank (three strengths / three areas to improve)
