# Slide Deck Conventions

Observed from BGA ICT decks in use (e.g. *Lesson #1 – Digital footprint*, from the Grade 7 Internet Safety, Cyber Security and Encryption unit). Follow this sequence when outlining a deck.

## Slide sequence

| # | Slide | Content |
|---|---|---|
| 1 | **Title** | Unit name as the heading, then `Lesson N: <lesson title>` beneath it |
| 2 | **Objectives** | Opens with *"In this lesson, you will learn:"* followed by a plain bulleted list, written to the student in second person |
| 3 | **Scenario setup** | The unit's running narrative. Establishes the student's role and the organisation they work for. |
| 4 | **Scenario task** | This lesson's specific job within that scenario |
| 5 | **Activity N.1 + DO NOW** | First activity, doubling as the Do Now |
| 6–n | **Content and discussion** | Teaching slides interleaved with discussion prompts. Discussion slides are a question or two, nothing else — e.g. *"What did James do wrong?"* / *"What conclusions might an employer draw from James' post?"* |
| n+1 | **Summary / tips** | A numbered or bulleted takeaway list |
| n+2 | **Activity N.2** | Second activity, often a Menti poll — slide carries the Menti links |
| n+3 | **Activity N.3** | Applied or extension task |
| last | **Quiz** | Kahoot link as the closing check |

## Conventions to keep

**Activity numbering** — `Activity <lesson>.<n>`. Lesson 1 has Activity 1.1, 1.2, 1.3; lesson 4 has Activity 4.1, 4.2. Numbering is continuous within a lesson, restarting each lesson.

**Objectives phrased to the student** — "you will learn", not "students will be able to". These are the student-facing version of the three-level LO from the lesson plan; the three levels stay in the plan, the deck shows the plain list.

**Two or three activities per lesson.** The observed pattern is a Do Now activity, a discussion or poll activity, and an applied activity.

**Discussion slides are sparse.** A question and nothing else. The slide is a prompt for talk, not a page of text — this supports the department's oracy strategy.

**Every lesson ends on a check.** A Kahoot quiz is the default closer. Existing shareable Kahoots cover Scratch, Word documents, and PPT topics; reuse where one exists rather than building a new one.

**Named characters in scenarios.** The cybersecurity unit uses invented applicants (Alina, James) whose social posts students analyse. Concrete named examples beat abstract description — invent them per unit.

## Tools referenced in decks

- **Menti** (Mentimeter) — live polling for opinion and prediction activities. Slides carry the participation links.
- **Kahoot** — end-of-lesson quiz. Links are shared as `create.kahoot.it/share/...`
- **Google Classroom / ManageBac** — where resources are uploaded before the lesson

## When generating a deck outline

Give the headline and the actual body content for each slide, not a description of what the slide would contain. Write the discussion questions themselves, the tip list itself, the scenario text itself — the outline should be close enough to paste.

Flag any slide that needs an asset you cannot generate (a screenshot of a fake social profile, a circuit diagram, a photo) so the teacher knows what to source.
